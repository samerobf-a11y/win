// طبقة البيانات: كل منطق الأعمال هنا (المبالغ بالفلس). تُستدعى من main.js فقط.
const Database = require('better-sqlite3'), crypto = require('crypto'), fs = require('fs'), path = require('path');
let db, dbPath;
const err = (m) => { throw new Error(m); };

function open(dir) {
  dbPath = path.join(dir, 'store.db');
  db = new Database(dbPath);
  db.pragma('journal_mode = WAL'); db.pragma('foreign_keys = ON');
  if (!db.prepare("SELECT 1 FROM sqlite_master WHERE name='settings'").get())
    db.exec(fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8'));
  migrate();
}
// ترحيل خفيف لقواعد بيانات أُنشئت بإصدار أقدم (يُنفَّذ كل مرة، وهو آمن للتكرار)
function migrate() {
  const cols = (t) => db.prepare(`PRAGMA table_info(${t})`).all().map((c) => c.name);
  if (!cols('invoices').includes('discount')) db.exec('ALTER TABLE invoices ADD COLUMN discount INTEGER NOT NULL DEFAULT 0');
  if (!cols('users').includes('perm_discount')) db.exec('ALTER TABLE users ADD COLUMN perm_discount INTEGER NOT NULL DEFAULT 0');
  db.prepare("INSERT OR IGNORE INTO settings(key,value) VALUES('employee_max_discount','20')").run();
  if (!db.prepare("SELECT 1 FROM sqlite_master WHERE name='purchases'").get()) {
    const sql = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');
    db.exec(sql.slice(sql.indexOf('CREATE TABLE purchases'), sql.indexOf('CREATE INDEX idx_purchases_branch_date')) + 'CREATE INDEX idx_purchases_branch_date ON purchases(branch_id, created_at);');
  }
  db.exec(`CREATE TABLE IF NOT EXISTS accounts (id INTEGER PRIMARY KEY, code TEXT NOT NULL UNIQUE, name TEXT NOT NULL, type TEXT NOT NULL CHECK(type IN ('asset','liability','equity','revenue','expense')), parent_id INTEGER REFERENCES accounts(id), active INTEGER NOT NULL DEFAULT 1);
    CREATE TABLE IF NOT EXISTS journal_entries (id INTEGER PRIMARY KEY, entry_date TEXT NOT NULL DEFAULT (date('now','localtime')), description TEXT NOT NULL, ref_type TEXT, ref_id INTEGER, user_id INTEGER REFERENCES users(id), created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')));
    CREATE TABLE IF NOT EXISTS journal_lines (id INTEGER PRIMARY KEY, entry_id INTEGER NOT NULL REFERENCES journal_entries(id) ON DELETE CASCADE, account_id INTEGER NOT NULL REFERENCES accounts(id), debit INTEGER NOT NULL DEFAULT 0, credit INTEGER NOT NULL DEFAULT 0, note TEXT);
    CREATE TABLE IF NOT EXISTS party_payments (id INTEGER PRIMARY KEY, kind TEXT NOT NULL CHECK(kind IN ('customer','supplier')), party_id INTEGER NOT NULL, branch_id INTEGER NOT NULL REFERENCES branches(id), amount INTEGER NOT NULL CHECK(amount>0), method TEXT NOT NULL CHECK(method IN ('cash','card')), note TEXT, user_id INTEGER REFERENCES users(id), created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')));
    CREATE INDEX IF NOT EXISTS idx_journal_date ON journal_entries(entry_date);
    CREATE INDEX IF NOT EXISTS idx_party_payments ON party_payments(kind, party_id);`);
  const seed=[['1000','الصندوق','asset'],['1100','البنك / البطاقات','asset'],['1200','ذمم العملاء','asset'],['2000','ذمم الموردين','liability'],['3000','رأس المال','equity'],['4000','المبيعات','revenue'],['5000','تكلفة المبيعات','expense'],['6000','المصروفات التشغيلية','expense']];
  const ins=db.prepare('INSERT OR IGNORE INTO accounts(code,name,type) VALUES(?,?,?)'); seed.forEach(x=>ins.run(...x));
}
const tx = (fn) => (...a) => db.transaction(fn)(...a);

// ---- كلمات المرور (scrypt مدمج في Node، بدون مكتبات إضافية)
const hash = (pw) => { const s = crypto.randomBytes(16).toString('hex'); return `scrypt$${s}$${crypto.scryptSync(pw, s, 64).toString('hex')}`; };
function verify(pw, h) {
  const [, s, k] = h.split('$'), a = Buffer.from(k, 'hex'), b = crypto.scryptSync(pw, s, 64);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
const needsSetup = () => !db.prepare("SELECT 1 FROM users WHERE role='admin'").get();
function createAdmin({ username, fullName, password }) {
  if (!needsSetup()) err('already_setup');
  if (!username || !fullName || !password || password.length < 8) err('weak_password');
  db.prepare("INSERT INTO users(username,password_hash,full_name,role) VALUES(?,?,?, 'admin')").run(username, hash(password), fullName);
}
function login(username, password) {
  const r = db.prepare('SELECT * FROM users WHERE username=? AND active=1').get(username);
  if (!r || !verify(password, r.password_hash)) return null;
  delete r.password_hash; return r;
}
function addUser({ username, fullName, password, branchId, lang = 'ar' }) {
  if (!password || password.length < 8 || !branchId) err('invalid_user');
  db.prepare("INSERT INTO users(username,password_hash,full_name,role,branch_id,lang) VALUES(?,?,?, 'sales',?,?)").run(username, hash(password), fullName, branchId, lang);
}

// ---- الإعدادات والفروع والمنتجات
const getSettings = () => Object.fromEntries(db.prepare('SELECT key,value FROM settings').all().map(r => [r.key, r.value]));
const setSettings = tx((o) => { const s = db.prepare('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value'); for (const [k, v] of Object.entries(o)) s.run(k, String(v)); });
const listBranches = () => db.prepare('SELECT * FROM branches WHERE active=1 ORDER BY id').all();
const addBranch = ({ name, code }) => {
  if (!name || !String(name).trim()) err('invalid_branch');
  return db.prepare('INSERT INTO branches(name,code) VALUES(?,?)').run(String(name).trim(), code || 'B' + (db.prepare('SELECT COALESCE(MAX(id),0)+1 n FROM branches').get().n)).lastInsertRowid;
};
const listProducts = () => db.prepare('SELECT p.*, g.name_ar group_name FROM products p LEFT JOIN product_groups g ON g.id=p.group_id WHERE p.active=1 ORDER BY p.id').all();
const groupId = (name) => {
  name = (name || '').trim(); if (!name) return null;
  const r = db.prepare('SELECT id FROM product_groups WHERE name_ar=?').get(name);
  return r ? r.id : db.prepare('INSERT INTO product_groups(name_ar) VALUES(?)').run(name).lastInsertRowid;
};
const saveProduct = tx((p) => {
  if (!p.name_ar || !(Number.isInteger(p.price) && p.price >= 0)) err('invalid_product');
  const g = p.group_name !== undefined ? groupId(p.group_name) : (p.group_id ?? null), bc = (p.barcode == null ? '' : String(p.barcode)).trim() || null, a = [String(p.name_ar).trim(), p.name_en ?? null, bc, g, p.price, p.cost || 0];
  if (p.id) {
    const old = db.prepare('SELECT cost FROM products WHERE id=?').get(p.id); if (!old) err('not_found');
    a[5] = p.cost ?? old.cost;  // تعديل الاسم/السعر لا يصفّر التكلفة
    return db.prepare('UPDATE products SET name_ar=?,name_en=?,barcode=?,group_id=?,price=?,cost=? WHERE id=?').run(...a, p.id);
  }
  return db.prepare('INSERT INTO products(name_ar,name_en,barcode,group_id,price,cost) VALUES(?,?,?,?,?,?)').run(...a);
});
const deleteProduct = (id) => db.prepare('UPDATE products SET active=0 WHERE id=?').run(id); // حذف ناعم: تبقى الفواتير القديمة سليمة

// ---- المخزون
function moveStock(b, p, d, reason, ref, uid, strict) {
  db.prepare('INSERT OR IGNORE INTO stock(branch_id,product_id,qty) VALUES(?,?,0)').run(b, p);
  if (strict && d < 0 && db.prepare('SELECT qty FROM stock WHERE branch_id=? AND product_id=?').get(b, p).qty + d < 0) err('insufficient_stock');
  db.prepare('UPDATE stock SET qty=qty+? WHERE branch_id=? AND product_id=?').run(d, b, p);
  db.prepare('INSERT INTO stock_movements(branch_id,product_id,qty_change,reason,ref_id,user_id) VALUES(?,?,?,?,?,?)').run(b, p, d, reason, ref, uid);
}
const getStock = (branchId) => db.prepare('SELECT s.*, p.name_ar FROM stock s JOIN products p ON p.id=s.product_id WHERE s.branch_id=?').all(branchId);

// ---- الفواتير (الأسعار من قاعدة البيانات وليس من الواجهة)
const createInvoice = tx((user, { branchId, items, payment, customerId, discount }) => {
  if (user.role === 'sales' && user.branch_id !== branchId) err('forbidden_branch');
  if (!branchId || !items?.length || !['cash', 'card'].includes(payment)) err('invalid_invoice');
  const vat = +db.prepare("SELECT value FROM settings WHERE key='vat_percent'").get().value;
  let total = 0;
  const lines = items.map(({ productId, qty }) => {
    const p = db.prepare('SELECT * FROM products WHERE id=? AND active=1').get(productId);
    if (!p || !Number.isInteger(qty) || qty < 1) err('invalid_item');
    total += p.price * qty; return { p, qty };
  });
  const gross = total;
  discount = discount == null ? 0 : discount;
  if (!Number.isInteger(discount) || discount < 0 || (discount > 0 && discount >= gross)) err('invalid_discount');
  if (discount > 0) {  // الخصم بصلاحية يمنحها المدير، وللموظف سقف نسبة يحدده المدير
    if (!can(user, 'discount')) err('forbidden');
    if (user.role !== 'admin' && discount * 100 > gross * (+(db.prepare("SELECT value FROM settings WHERE key='employee_max_discount'").get()?.value) || 0)) err('discount_too_high');
  }
  if (customerId != null && !db.prepare('SELECT 1 FROM customers WHERE id=?').get(customerId)) err('invalid_customer');
  total = gross - discount;
  const subtotal = Math.round(total / (1 + vat / 100)), vatAmt = total - subtotal;
  db.prepare('UPDATE branches SET last_invoice_no=last_invoice_no+1 WHERE id=?').run(branchId);
  const number = db.prepare('SELECT last_invoice_no n FROM branches WHERE id=?').get(branchId).n;
  const id = db.prepare('INSERT INTO invoices(branch_id,number,user_id,customer_id,payment_method,vat_percent,subtotal,vat_amount,total,discount) VALUES(?,?,?,?,?,?,?,?,?,?)')
    .run(branchId, number, user.id, customerId ?? null, payment, vat, subtotal, vatAmt, total, discount).lastInsertRowid;
  for (const { p, qty } of lines) {
    db.prepare('INSERT INTO invoice_items(invoice_id,product_id,name,qty,unit_price,line_total) VALUES(?,?,?,?,?,?)').run(id, p.id, p.name_ar, qty, p.price, p.price * qty);
    if (p.track_stock) moveStock(branchId, p.id, -qty, 'sale', id, user.id, true);
  }
  if (discount > 0) audit(user, 'discount_invoice', branchId, number, { gross, discount, total });
  return { id, number, subtotal, vat: vatAmt, total, discount };
});

// ---- النقل بين الفروع: مسودة ← مُرسَل ← مستلَم (بتأكيد الفرع المستلم)
const createTransfer = tx((user, { from, to, items, note }) => {
  if (!items?.length || from === to) err('invalid_transfer');
  const id = db.prepare('INSERT INTO stock_transfers(from_branch_id,to_branch_id,note,created_by) VALUES(?,?,?,?)').run(from, to, note || null, user.id).lastInsertRowid;
  for (const { productId, qty } of items) {
    if (!Number.isInteger(qty) || qty < 1) err('invalid_item');
    db.prepare('INSERT INTO stock_transfer_items(transfer_id,product_id,qty) VALUES(?,?,?)').run(id, productId, qty);
  }
  return id;
});
const getTransfer = (id, status) => {
  const t = db.prepare('SELECT * FROM stock_transfers WHERE id=?').get(id);
  if (!t) err('not_found'); if (t.status !== status) err('bad_status'); return t;
};
const tItems = (id) => db.prepare('SELECT * FROM stock_transfer_items WHERE transfer_id=?').all(id);
const sendTransfer = tx((user, id) => {
  const t = getTransfer(id, 'draft');
  for (const i of tItems(id)) moveStock(t.from_branch_id, i.product_id, -i.qty, 'transfer_out', id, user.id, true);
  db.prepare("UPDATE stock_transfers SET status='sent', sent_at=datetime('now') WHERE id=?").run(id);
});
const receiveTransfer = tx((user, id) => {
  const t = getTransfer(id, 'sent');
  if (user.role === 'sales' && user.branch_id !== t.to_branch_id) err('forbidden_branch');
  for (const i of tItems(id)) moveStock(t.to_branch_id, i.product_id, i.qty, 'transfer_in', id, user.id, false);
  db.prepare("UPDATE stock_transfers SET status='received', received_at=datetime('now') WHERE id=?").run(id);
});
const cancelTransfer = (id) => { getTransfer(id, 'draft'); db.prepare("UPDATE stock_transfers SET status='cancelled' WHERE id=?").run(id); };
const listTransfers = (user) => {
  const rows = user.role === 'admin' ? db.prepare('SELECT * FROM stock_transfers ORDER BY id DESC').all()
    : db.prepare('SELECT * FROM stock_transfers WHERE from_branch_id=? OR to_branch_id=? ORDER BY id DESC').all(user.branch_id, user.branch_id);
  const it = db.prepare('SELECT i.product_id, i.qty, p.name_ar name FROM stock_transfer_items i JOIN products p ON p.id=i.product_id WHERE i.transfer_id=?');
  return rows.map(t => ({ ...t, items: it.all(t.id) }));
};

// ---- التقارير: بدون branchId للمدير = صفوف لكل فرع (المجموع = التقرير المجمّع)
function salesReport(user, { branchId, from, to }) {
  const b = user.role === 'sales' ? user.branch_id : branchId, w = ["status='posted'", 'date(created_at) BETWEEN ? AND ?'], a = [from, to];
  if (b) { w.push('branch_id=?'); a.push(b); }
  return db.prepare(`SELECT branch_id, COUNT(*) invoices, SUM(subtotal) subtotal, SUM(vat_amount) vat, SUM(total) total, SUM(discount) discount FROM invoices WHERE ${w.join(' AND ')} GROUP BY branch_id`).all(...a);
}

// ---- سجل المبيعات + الصلاحيات + إنهاء اليوم
// المدير: كل شيء. الموظف: فقط ما منحه المدير (عرض/تعديل/حذف)، على مبيعاته هو، ليوم اليوم، وطالما لم تُرحَّل.
const can = (u, a) => u.role === 'admin' || !!db.prepare(`SELECT perm_${a} p FROM users WHERE id=? AND active=1`).get(u.id)?.p; // يُقرأ من القاعدة لتسري التغييرات فوراً
const audit = (u, action, branchId, no, detail) => db.prepare('INSERT INTO audit_log(user_id,action,branch_id,invoice_no,detail) VALUES(?,?,?,?,?)').run(u.id, action, branchId ?? null, no ?? null, detail ? JSON.stringify(detail) : null);
const today = () => db.prepare("SELECT date('now','localtime') d").get().d;

const setPermissions = tx((admin, { userId, view, edit, delete: del, discount }) => {
  const t = db.prepare("SELECT * FROM users WHERE id=? AND role='sales'").get(userId); if (!t) err('not_found');
  db.prepare('UPDATE users SET perm_view=?,perm_edit=?,perm_delete=?,perm_discount=? WHERE id=?').run(+!!view, +!!edit, +!!del, +!!discount, userId);
  audit(admin, 'set_permissions', t.branch_id, null, { userId, view: !!view, edit: !!edit, delete: !!del, discount: !!discount });
});
const listUsers = () => db.prepare("SELECT id,username,full_name,role,branch_id,perm_view,perm_edit,perm_delete,perm_discount,active FROM users WHERE active=1 ORDER BY id").all();

function listSales(user, { branchId, date } = {}) {
  let w = [], a = [];
  if (user.role === 'admin') { w.push('date(i.created_at)=?'); a.push(date || today()); if (branchId) { w.push('i.branch_id=?'); a.push(branchId); } }
  else { if (!can(user, 'view')) err('forbidden'); w.push('i.user_id=?', "date(i.created_at)=date('now','localtime')"); a.push(user.id); }
  const rows = db.prepare(`SELECT i.*, u.full_name employee, u.username, c.name customer FROM invoices i JOIN users u ON u.id=i.user_id LEFT JOIN customers c ON c.id=i.customer_id WHERE ${w.join(' AND ')} ORDER BY i.id DESC`).all(...a);
  return withItems(rows);
}
function withItems(rows) {
  const it = db.prepare('SELECT ii.*, g.name_ar grp FROM invoice_items ii LEFT JOIN products p ON p.id=ii.product_id LEFT JOIN product_groups g ON g.id=p.group_id WHERE ii.invoice_id=?');
  return rows.map(r => ({ ...r, items: it.all(r.id) }));
}
// كل الفواتير (مفتوحة ومرحّلة) للوحة التحكم والتقارير - للمدير فقط
const allInvoices = () => withItems(db.prepare('SELECT i.*, u.full_name employee, u.username, c.name customer FROM invoices i JOIN users u ON u.id=i.user_id LEFT JOIN customers c ON c.id=i.customer_id ORDER BY i.id').all());
// يرجع الفاتورة بعد التحقق من الملكية والحالة؛ يُستدعى داخل معاملة
function ownOpenInvoice(user, id, action) {
  if (!can(user, action)) err('forbidden');
  const inv = db.prepare('SELECT * FROM invoices WHERE id=?').get(id); if (!inv) err('not_found');
  if (inv.status !== 'open') err('already_posted');
  if (user.role === 'sales' && (inv.user_id !== user.id || inv.created_at.slice(0, 10) !== today())) err('forbidden');
  return inv;
}
const deleteSale = tx((user, id) => {
  const inv = ownOpenInvoice(user, id, 'delete'), items = db.prepare('SELECT * FROM invoice_items WHERE invoice_id=?').all(id);
  for (const it of items) if (db.prepare('SELECT track_stock t FROM products WHERE id=?').get(it.product_id)?.t) moveStock(inv.branch_id, it.product_id, it.qty, 'return', id, user.id, false);
  audit(user, 'delete_invoice', inv.branch_id, inv.number, { total: inv.total, payment: inv.payment_method, employee_id: inv.user_id, items: items.map(i => ({ name: i.name, qty: i.qty, price: i.unit_price })) });
  db.prepare('DELETE FROM invoices WHERE id=?').run(id);
});
// items: [{ itemId, qty }] — الكمية 0 تحذف السطر؛ الأسعار تبقى كما بيعت. payment اختياري.
const updateSale = tx((user, { id, items, payment }) => {
  const inv = ownOpenInvoice(user, id, 'edit'), cur = db.prepare('SELECT * FROM invoice_items WHERE invoice_id=?').all(id);
  if (payment && !['cash', 'card'].includes(payment)) err('invalid_invoice');
  const q = new Map((items || []).map(x => [x.itemId, x.qty]));
  for (const v of q.values()) if (!Number.isInteger(v) || v < 0) err('invalid_item');
  let total = 0;
  for (const it of cur) {
    const nq = q.has(it.id) ? q.get(it.id) : it.qty, d = it.qty - nq;
    if (d && db.prepare('SELECT track_stock t FROM products WHERE id=?').get(it.product_id)?.t) moveStock(inv.branch_id, it.product_id, d, d > 0 ? 'return' : 'sale', id, user.id, true);
    if (nq === 0) db.prepare('DELETE FROM invoice_items WHERE id=?').run(it.id);
    else db.prepare('UPDATE invoice_items SET qty=?, line_total=? WHERE id=?').run(nq, nq * it.unit_price, it.id);
    total += nq * it.unit_price;
  }
  if (total === 0) err('empty_invoice'); // لحذف الفاتورة كلها استخدم الحذف
  const gross = total, disc = inv.discount || 0;  // الخصم مبلغ ثابت يبقى كما هو بعد تعديل الكميات
  if (disc >= gross) err('invalid_discount');
  if (disc > 0 && user.role !== 'admin' && disc * 100 > gross * (+(db.prepare("SELECT value FROM settings WHERE key='employee_max_discount'").get()?.value) || 0)) err('discount_too_high');
  total = gross - disc;
  const sub = Math.round(total / (1 + inv.vat_percent / 100));
  db.prepare('UPDATE invoices SET subtotal=?,vat_amount=?,total=?,payment_method=? WHERE id=?').run(sub, total - sub, total, payment || inv.payment_method, id);
  audit(user, 'edit_invoice', inv.branch_id, inv.number, { before: { total: inv.total, payment: inv.payment_method, items: cur.map(i => ({ name: i.name, qty: i.qty })) }, after: { total, payment: payment || inv.payment_method } });
});
// ملخص الموظفين غير المرحّل (قبل الضغط على إنهاء اليوم)
const openSummary = (admin, { branchId } = {}) => db.prepare(`SELECT u.full_name employee, COUNT(*) invoices,
  SUM(CASE WHEN i.payment_method='cash' THEN i.total ELSE 0 END) cash, SUM(CASE WHEN i.payment_method='card' THEN i.total ELSE 0 END) card, SUM(i.total) total
  FROM invoices i JOIN users u ON u.id=i.user_id WHERE i.status='open' ${branchId ? 'AND i.branch_id=?' : ''} GROUP BY i.user_id`).all(...(branchId ? [branchId] : []));
// زر "إنهاء اليوم": ترحيل يدوي (المدير فقط) — بعده تظهر المبيعات في التقارير والحسابات وتُقفل
const endOfDay = tx((admin, { branchId } = {}) => {
  const w = branchId ? 'AND branch_id=?' : '', a = branchId ? [branchId] : [];
  const s = db.prepare(`SELECT COUNT(*) c, COALESCE(SUM(total),0) t FROM invoices WHERE status='open' ${w}`).get(...a);
  if (!s.c) err('nothing_to_post');
  const id = db.prepare('INSERT INTO end_of_day(branch_id,user_id,invoices,total) VALUES(?,?,?,?)').run(branchId || null, admin.id, s.c, s.t).lastInsertRowid;
  db.prepare(`UPDATE invoices SET status='posted', posted_at=datetime('now','localtime'), eod_id=? WHERE status='open' ${w}`).run(id, ...a);
  audit(admin, 'end_of_day', branchId, null, { eod_id: id, invoices: s.c, total: s.t });
  return { id, invoices: s.c, total: s.t };
});
const listEndOfDay = () => db.prepare('SELECT e.*, u.full_name by_user FROM end_of_day e JOIN users u ON u.id=e.user_id ORDER BY e.id DESC LIMIT 30').all();
const listAudit = () => db.prepare('SELECT a.*, u.full_name by_user FROM audit_log a JOIN users u ON u.id=a.user_id ORDER BY a.id DESC LIMIT 100').all();

module.exports = { open, needsSetup, createAdmin, login, addUser, getSettings, setSettings, listBranches, addBranch, listProducts, saveProduct,
  getStock, setPermissions, listUsers, listSales, deleteSale, updateSale, openSummary, endOfDay, listEndOfDay, listAudit, createInvoice, createTransfer, sendTransfer, receiveTransfer, cancelTransfer, listTransfers, salesReport };

// ---- توسعات للواجهة: مخزون، فروع، مستخدمون، مصروفات، عملاء/موردون
const adjustStock = tx((admin, { branchId, productId, qty }) => {
  if (!Number.isInteger(qty) || qty < 1 || !branchId || !productId) err('invalid_item');
  moveStock(branchId, productId, qty, 'adjustment', null, admin.id, false);
});
const deleteBranch = tx((id) => {
  const others = db.prepare('SELECT id FROM branches WHERE active=1 AND id<>? ORDER BY id').all(id);
  if (!others.length) err('last_branch');
  db.prepare('UPDATE branches SET active=0 WHERE id=?').run(id);
  db.prepare('UPDATE users SET branch_id=? WHERE branch_id=?').run(others[0].id, id); // الموظفون ينتقلون لأول فرع نشط
});
const deleteUser = (id) => { if (!db.prepare("UPDATE users SET active=0 WHERE id=? AND role='sales'").run(id).changes) err('not_found'); };
const addExpense = (user, { branchId, category, amount, note }) => {
  if (!branchId || !category || !Number.isInteger(amount) || amount < 1) err('invalid_expense');
  return db.prepare('INSERT INTO expenses(branch_id,category,amount,note,user_id) VALUES(?,?,?,?,?)').run(branchId, category, amount, note || null, user.id).lastInsertRowid;
};
const listExpenses = () => db.prepare('SELECT * FROM expenses ORDER BY id DESC').all();
const KIND = { cust: 'customers', supp: 'suppliers' }, tbl = (k) => KIND[k] || err('invalid_kind');
const listParties = ({ kind }) => db.prepare(`SELECT * FROM ${tbl(kind)} ORDER BY id`).all();
const addParty = ({ kind, name, phone, trn }) => { if (!name || !String(name).trim()) err('invalid_party'); return db.prepare(`INSERT INTO ${tbl(kind)}(name,phone,trn) VALUES(?,?,?)`).run(String(name).trim(), phone || null, trn || null).lastInsertRowid; };
const deleteParty = ({ kind, id }) => { db.prepare(`DELETE FROM ${tbl(kind)} WHERE id=?`).run(id); };
Object.assign(module.exports, { deleteProduct, allInvoices, adjustStock, deleteBranch, deleteUser, addExpense, listExpenses, listParties, addParty, deleteParty });

// ---- النسخ الاحتياطي: لقطة متسقة للقاعدة (آمنة أثناء العمل) + فحص ملف قبل الاستعادة
const snapshot = (file) => { db.prepare('VACUUM INTO ?').run(file); };
const dbFile = () => dbPath;
const closeDb = () => { db.close(); };
function validateFile(file) {
  let t; try {
    t = new Database(file, { readonly: true, fileMustExist: true });
    const n = t.prepare("SELECT COUNT(*) c FROM sqlite_master WHERE name IN ('settings','users','invoices','products')").get().c;
    return n === 4;
  } catch (_) { return false; } finally { try { t && t.close(); } catch (_) {} }
}
Object.assign(module.exports, { snapshot, dbFile, closeDb, validateFile });
const updateParty = ({ kind, id, name, phone, trn }) => {
  if (!name || !String(name).trim()) err('invalid_party');
  if (!db.prepare(`UPDATE ${tbl(kind)} SET name=?,phone=?,trn=? WHERE id=?`).run(String(name).trim(), phone || null, trn || null, id).changes) err('not_found');
};
Object.assign(module.exports, { updateParty });

// ---- فواتير الشراء (المدير فقط): تزيد المخزون وتحدّث آخر تكلفة، والآجل يزيد رصيد المورد
const createPurchase = tx((user, { branchId, supplierId, refNo, payment, items, note }) => {
  if (!branchId || !items?.length || !['cash', 'credit'].includes(payment) || (payment === 'credit' && !supplierId)) err('invalid_purchase');
  if (!db.prepare('SELECT 1 FROM branches WHERE id=? AND active=1').get(branchId)) err('invalid_purchase');
  if (supplierId && !db.prepare('SELECT 1 FROM suppliers WHERE id=?').get(supplierId)) err('not_found');
  let total = 0;
  const lines = items.map(({ productId, qty, unitCost }) => {
    const p = db.prepare('SELECT id, track_stock FROM products WHERE id=? AND active=1').get(productId);
    if (!p || !Number.isInteger(qty) || qty < 1 || !Number.isInteger(unitCost) || unitCost < 0) err('invalid_item');
    total += qty * unitCost; return { p, qty, unitCost };
  });
  const id = db.prepare('INSERT INTO purchases(branch_id,supplier_id,ref_no,payment,total,note,user_id) VALUES(?,?,?,?,?,?,?)')
    .run(branchId, supplierId || null, refNo || null, payment, total, note || null, user.id).lastInsertRowid;
  const ins = db.prepare('INSERT INTO purchase_items(purchase_id,product_id,qty,unit_cost,line_total) VALUES(?,?,?,?,?)');
  for (const { p, qty, unitCost } of lines) {
    ins.run(id, p.id, qty, unitCost, qty * unitCost);
    if (p.track_stock) moveStock(branchId, p.id, qty, 'purchase', id, user.id, false);
    db.prepare('UPDATE products SET cost=? WHERE id=?').run(unitCost, p.id);
  }
  if (payment === 'credit') db.prepare('UPDATE suppliers SET balance=balance+? WHERE id=?').run(total, supplierId);
  return id;
});
const listPurchases = ({ branchId } = {}) => {
  const rows = branchId ? db.prepare('SELECT pu.*, s.name supplier_name FROM purchases pu LEFT JOIN suppliers s ON s.id=pu.supplier_id WHERE pu.branch_id=? ORDER BY pu.id DESC').all(branchId)
    : db.prepare('SELECT pu.*, s.name supplier_name FROM purchases pu LEFT JOIN suppliers s ON s.id=pu.supplier_id ORDER BY pu.id DESC').all();
  const it = db.prepare('SELECT i.product_id, i.qty, i.unit_cost, i.line_total, p.name_ar name FROM purchase_items i JOIN products p ON p.id=i.product_id WHERE i.purchase_id=?');
  return rows.map((r) => ({ ...r, items: it.all(r.id) }));
};
Object.assign(module.exports, { createPurchase, listPurchases });


// ---- الجرد والتنبيهات والمحاسبة
const lowStock = (branchId) => db.prepare(`SELECT s.branch_id,s.product_id,s.qty,s.min_qty,p.name_ar FROM stock s JOIN products p ON p.id=s.product_id WHERE s.min_qty>0 AND s.qty<=s.min_qty ${branchId ? 'AND s.branch_id=?' : ''} ORDER BY (s.min_qty-s.qty) DESC`).all(...(branchId ? [branchId] : []));
const setMinStock = tx((admin, { branchId, productId, minQty }) => { if (!branchId || !productId || !Number.isInteger(minQty) || minQty < 0) err('invalid_item'); db.prepare('INSERT OR IGNORE INTO stock(branch_id,product_id,qty) VALUES(?,?,0)').run(branchId,productId); db.prepare('UPDATE stock SET min_qty=? WHERE branch_id=? AND product_id=?').run(minQty,branchId,productId); });
const inventoryAdjust = tx((admin, { branchId, productId, actualQty }) => { if (!branchId || !productId || !Number.isInteger(actualQty) || actualQty < 0) err('invalid_item'); const cur=db.prepare('SELECT qty FROM stock WHERE branch_id=? AND product_id=?').get(branchId,productId)?.qty||0; moveStock(branchId,productId,actualQty-cur,'adjustment',null,admin.id,false); return { before:cur, actual:actualQty, delta:actualQty-cur }; });
const accountList = () => db.prepare('SELECT * FROM accounts WHERE active=1 ORDER BY code').all();
const journalList = ({from,to,limit=200}={}) => { const w=[],a=[]; if(from){w.push('entry_date>=?');a.push(from)} if(to){w.push('entry_date<=?');a.push(to)} const rows=db.prepare(`SELECT j.*,u.full_name user_name FROM journal_entries j LEFT JOIN users u ON u.id=j.user_id ${w.length?'WHERE '+w.join(' AND '):''} ORDER BY j.entry_date DESC,j.id DESC LIMIT ?`).all(...a,Math.min(500,Math.max(1,limit))); const l=db.prepare('SELECT l.*,a.code,a.name FROM journal_lines l JOIN accounts a ON a.id=l.account_id WHERE l.entry_id=?'); return rows.map(r=>({...r,lines:l.all(r.id)})); };
function postEntry(user, description, refType, refId, lines) { const totalD=lines.reduce((a,x)=>a+x.debit,0), totalC=lines.reduce((a,x)=>a+x.credit,0); if(totalD!==totalC) err('unbalanced_entry'); const id=db.prepare('INSERT INTO journal_entries(description,ref_type,ref_id,user_id) VALUES(?,?,?,?)').run(description,refType||null,refId||null,user.id).lastInsertRowid; const q=db.prepare('SELECT id FROM accounts WHERE code=?'); const ins=db.prepare('INSERT INTO journal_lines(entry_id,account_id,debit,credit,note) VALUES(?,?,?,?,?)'); lines.forEach(x=>{const a=q.get(x.code);if(!a)err('not_found');ins.run(id,a.id,x.debit||0,x.credit||0,x.note||null)}); return id; }
const accountSummary = ({from,to,branchId}={}) => { const w=["status='posted'"],a=[]; if(from){w.push('date(created_at)>=?');a.push(from)} if(to){w.push('date(created_at)<=?');a.push(to)} if(branchId){w.push('branch_id=?');a.push(branchId)} const sales=db.prepare(`SELECT COALESCE(SUM(subtotal),0) v,COALESCE(SUM(total),0) total,COALESCE(SUM(vat_amount),0) vat FROM invoices WHERE ${w.join(' AND ')}`).get(...a); const ew=[],ea=[]; if(from){ew.push('date(created_at)>=?');ea.push(from)} if(to){ew.push('date(created_at)<=?');ea.push(to)} if(branchId){ew.push('branch_id=?');ea.push(branchId)} const exp=db.prepare(`SELECT COALESCE(SUM(amount),0) v FROM expenses ${ew.length?'WHERE '+ew.join(' AND '):''}`).get(...ea).v; return {...sales,expenses:exp,net:sales.subtotal-exp}; };
const partyBalances = (kind) => db.prepare(`SELECT id,name,phone,balance FROM ${kind==='customer'?'customers':'suppliers'} WHERE balance<>0 ORDER BY ABS(balance) DESC`).all();
const payParty = tx((user,{kind,partyId,branchId,amount,method='cash',note}) => { if(!['customer','supplier'].includes(kind)||!partyId||!branchId||!Number.isInteger(amount)||amount<1||!['cash','card'].includes(method)) err('invalid_item'); const table=kind==='customer'?'customers':'suppliers'; const exists=db.prepare(`SELECT balance FROM ${table} WHERE id=?`).get(partyId); if(!exists)err('not_found'); const signed=kind==='customer'?-amount:-amount; db.prepare(`UPDATE ${table} SET balance=balance+? WHERE id=?`).run(signed,partyId); const id=db.prepare('INSERT INTO party_payments(kind,party_id,branch_id,amount,method,note,user_id) VALUES(?,?,?,?,?,?,?)').run(kind,partyId,branchId,amount,method,note||null,user.id).lastInsertRowid; postEntry(user,kind==='customer'?'تحصيل من عميل':'سداد مورد',kind,id,kind==='customer'?[{code:method==='cash'?'1000':'1100',debit:amount},{code:'1200',credit:amount}]:[{code:'2000',debit:amount},{code:method==='cash'?'1000':'1100',credit:amount}]); return id; });
const paymentList = ({kind}={}) => db.prepare(`SELECT p.*,CASE WHEN p.kind='customer' THEN c.name ELSE s.name END party_name,b.name branch_name FROM party_payments p LEFT JOIN customers c ON p.kind='customer' AND c.id=p.party_id LEFT JOIN suppliers s ON p.kind='supplier' AND s.id=p.party_id JOIN branches b ON b.id=p.branch_id ${kind?'WHERE p.kind=?':''} ORDER BY p.id DESC`).all(...(kind?[kind]:[]));
Object.assign(module.exports,{lowStock,setMinStock,inventoryAdjust,accountList,journalList,accountSummary,partyBalances,payParty,paymentList});
