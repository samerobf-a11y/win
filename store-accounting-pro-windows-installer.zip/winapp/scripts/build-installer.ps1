$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot\..
Write-Host "Installing production dependencies..." -ForegroundColor Cyan
npm install
Write-Host "Building Windows NSIS installer..." -ForegroundColor Cyan
npm run dist
Write-Host "Done. Check the dist folder." -ForegroundColor Green
