const { contextBridge, ipcRenderer } = require('electron');
const ALLOWED = /^(auth|settings|branch|user|product|stock|invoice|transfer|report|sales|backup|print|purchase|expense|account|party):[a-zA-Z]+$/;
contextBridge.exposeInMainWorld('api', {
  call: (channel, arg) => ALLOWED.test(channel) ? ipcRenderer.invoke(channel, arg) : Promise.reject(new Error('blocked'))
});
