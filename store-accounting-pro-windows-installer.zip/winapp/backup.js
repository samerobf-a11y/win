// النسخ الاحتياطي والاستعادة. النسخ تُحفظ في مجلد التطبيق، ونسخة إضافية اختيارية في مجلد آخر (فلاشة، قرص خارجي، OneDrive...).
const fs = require('fs'), path = require('path'), db = require('./db');
const RE = /^(store|prerestore)-\d{8}-\d{6}-\d{3}\.db$/;
const pad = (n, l = 2) => String(n).padStart(l, '0');
const stamp = (d = new Date()) => `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}-${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}-${pad(d.getMilliseconds(), 3)}`;

function settings() {
  const s = db.getSettings();
  return { extra: (s.backup_dir || '').trim(), keep: Math.max(3, parseInt(s.backup_keep) || 30), auto: s.backup_auto !== '0' };
}
function list(dir) {
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir).filter((f) => RE.test(f)).sort().reverse().map((name) => { const st = fs.statSync(path.join(dir, name)); return { name, size: st.size, mtime: st.mtime.toISOString(), safety: name.startsWith('prerestore') }; });
}
function prune(dir, keep, prefix) {
  list(dir).filter((f) => f.name.startsWith(prefix + '-')).slice(keep).forEach((f) => { try { fs.unlinkSync(path.join(dir, f.name)); } catch (_) {} });
}
// نسخة جديدة. فشل المجلد الإضافي لا يُفشل النسخة الأساسية، لكن يُرجَع في النتيجة ليظهر للمستخدم.
function make(dir, prefix = 'store') {
  fs.mkdirSync(dir, { recursive: true });
  const file = path.join(dir, `${prefix}-${stamp()}.db`), c = settings(), r = { name: path.basename(file), extra: null };
  db.snapshot(file); r.size = fs.statSync(file).size;
  if (c.extra) {
    try { fs.mkdirSync(c.extra, { recursive: true }); fs.copyFileSync(file, path.join(c.extra, r.name)); prune(c.extra, c.keep, 'store'); r.extra = 'ok'; }
    catch (_) { r.extra = 'failed'; }
  }
  prune(dir, prefix === 'store' ? c.keep : 5, prefix);
  return r;
}
// تلقائي: إن لم تُؤخذ نسخة خلال آخر 24 ساعة (أو force)
function auto(dir, force = false) {
  const c = settings(); if (!c.auto && !force) return null;
  const last = list(dir).find((f) => !f.safety);
  if (!force && last && Date.now() - new Date(last.mtime).getTime() < 24 * 3600 * 1000) return null;
  return make(dir);
}
// الاستعادة: من نسخة في المجلد (name) أو من ملف خارجي (file). تُؤخذ نسخة أمان أولاً ثم يُعاد تشغيل البرنامج.
function restore(dir, { name, file }, relaunch) {
  let src;
  if (name) { if (!RE.test(name) || !fs.existsSync(path.join(dir, name))) throw new Error('not_found'); src = path.join(dir, name); }
  else if (file) src = file; else throw new Error('not_found');
  if (!db.validateFile(src)) throw new Error('invalid_backup');
  make(dir, 'prerestore');
  const target = db.dbFile();
  db.closeDb();
  for (const x of ['-wal', '-shm']) try { fs.unlinkSync(target + x); } catch (_) {}
  fs.copyFileSync(src, target);
  relaunch();
}
module.exports = { list, make, auto, restore, settings, RE };
