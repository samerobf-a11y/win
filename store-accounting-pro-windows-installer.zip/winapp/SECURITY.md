# Windows production hardening

- `app.asar` packaging with maximum compression.
- `contextIsolation`, `sandbox`, `nodeIntegration: false`, and allow-listed IPC channels.
- External navigation and new windows blocked.
- DevTools shortcuts disabled in packaged builds.
- Single-instance lock and safe database close on exit.
- User permissions checked in the main process.
- NSIS x64 installer with custom icon, Start Menu entry, and desktop shortcut.

No desktop application can be made completely immune to reverse engineering when it runs on the user's machine. For real production protection, sign the installer and executable with a trusted Windows Code Signing certificate. Set `CSC_LINK` and `CSC_KEY_PASSWORD` before running the build script.
