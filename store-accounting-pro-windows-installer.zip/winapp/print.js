// إرسال البايتات الخام إلى الطابعة: شبكة (TCP 9100) أو USB عبر مدير الطباعة في ويندوز (RAW). بلا مكتبات إضافية.
const net = require('net'), fs = require('fs'), os = require('os'), path = require('path'), { execFile } = require('child_process');

function sendNetwork(ip, port, buf, timeoutMs = 6000) {
  return new Promise((resolve, reject) => {
    if (!ip) return reject(new Error('printer_not_configured'));
    const s = net.connect({ host: ip, port: +port || 9100 });
    const fail = (e) => { s.destroy(); reject(new Error('printer_unreachable')); };
    s.setTimeout(timeoutMs, fail); s.on('error', fail);
    s.on('connect', () => s.end(buf, () => resolve()));
  });
}

// PowerShell + winspool.drv: يرسل البيانات كما هي (RAW) دون المرور بتعريف الطابعة
const PS = `param([string]$Printer,[string]$Data)
$sig=@'
using System;using System.Runtime.InteropServices;
public class RawPrint{
[StructLayout(LayoutKind.Sequential,CharSet=CharSet.Unicode)]public class DOCINFO{[MarshalAs(UnmanagedType.LPWStr)]public string n;[MarshalAs(UnmanagedType.LPWStr)]public string o;[MarshalAs(UnmanagedType.LPWStr)]public string t;}
[DllImport("winspool.drv",CharSet=CharSet.Unicode,SetLastError=true)]public static extern bool OpenPrinter(string p,out IntPtr h,IntPtr d);
[DllImport("winspool.drv",SetLastError=true)]public static extern bool ClosePrinter(IntPtr h);
[DllImport("winspool.drv",CharSet=CharSet.Unicode,SetLastError=true)]public static extern bool StartDocPrinter(IntPtr h,int l,[In]DOCINFO d);
[DllImport("winspool.drv",SetLastError=true)]public static extern bool EndDocPrinter(IntPtr h);
[DllImport("winspool.drv",SetLastError=true)]public static extern bool StartPagePrinter(IntPtr h);
[DllImport("winspool.drv",SetLastError=true)]public static extern bool EndPagePrinter(IntPtr h);
[DllImport("winspool.drv",SetLastError=true)]public static extern bool WritePrinter(IntPtr h,byte[] b,int c,out int w);
public static void Send(string printer,byte[] data){IntPtr h;if(!OpenPrinter(printer,out h,IntPtr.Zero))throw new Exception("open");
var d=new DOCINFO();d.n="Receipt";d.t="RAW";try{if(!StartDocPrinter(h,1,d))throw new Exception("doc");StartPagePrinter(h);int w;if(!WritePrinter(h,data,data.Length,out w))throw new Exception("write");EndPagePrinter(h);EndDocPrinter(h);}finally{ClosePrinter(h);}}}
'@
Add-Type -TypeDefinition $sig
if(-not $Printer){$Printer=(Get-CimInstance Win32_Printer|Where-Object{$_.Default}).Name}
[RawPrint]::Send($Printer,[IO.File]::ReadAllBytes($Data))`;

function sendWindows(printerName, buf) {
  return new Promise((resolve, reject) => {
    if (process.platform !== 'win32') return reject(new Error('usb_windows_only'));
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'rcpt-')), ps = path.join(dir, 'p.ps1'), bin = path.join(dir, 'r.bin');
    fs.writeFileSync(ps, '﻿' + PS, 'utf8'); fs.writeFileSync(bin, buf);
    const args = ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ps, ...(printerName ? ['-Printer', printerName] : []), '-Data', bin];
    execFile('powershell.exe', args, { timeout: 20000, windowsHide: true }, (e) => {
      try { fs.rmSync(dir, { recursive: true, force: true }); } catch (_) {}
      e ? reject(new Error('printer_failed')) : resolve();
    });
  });
}

// settings: كائن الإعدادات من قاعدة البيانات (printer_type: usb | net)
const send = (s, buf) => s.printer_type === 'net' ? sendNetwork(s.printer_ip, s.printer_port, buf) : sendWindows(s.printer_name, buf);

module.exports = { send, sendNetwork, sendWindows };
