const { app, BrowserWindow, ipcMain, dialog } = require('electron'), path = require('path'), fs = require('fs'), db = require('./db'), escpos = require('./escpos'), printer = require('./print'), backup = require('./backup');
let win, user = null;
const gotLock = app.requestSingleInstanceLock();
if (!gotLock) app.quit();
else app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });

// كل قناة تتحقق من الصلاحية هنا، لا تعتمد على الواجهة
function handle(ch, roles, fn) {
  ipcMain.handle(ch, async (_, arg) => {
    try {
      if (roles && (!user || !roles.includes(user.role))) throw new Error('forbidden');
      return { ok: true, data: await fn(arg) };
    } catch (e) { return { ok: false, error: e.message }; }
  });
}
const ANY = ['admin', 'sales'], ADMIN = ['admin'];
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => '&#' + c.charCodeAt(0) + ';');

// الطابعة الافتراضية: حرارية ESC/POS عامة بعرض 80mm (متوافقة مع Epson TM-T20 وXprinter XP-80 وأغلب الطابعات الحرارية). كل شيء قابل للتعديل من الإعدادات.
const PRINTER_DEFAULTS = { printer_mode: 'escpos', printer_model: 'generic-escpos-80', printer_type: 'usb', printer_name: '', printer_ip: '', printer_port: '9100', paper_width: '80', printer_cut: '1', printer_drawer: '0' };

// يحوّل الإيصال (HTML من الواجهة) إلى صورة نقطية بعرض الورقة ثم يرسلها بأوامر ESC/POS.
// نافذة مخفية بدون JavaScript ولا شبكة، والإعدادات تُقرأ من القاعدة وليس من الواجهة.
async function printHtml({ html, dir }) {
  const s = { ...PRINTER_DEFAULTS, ...db.getSettings() };
  if (s.printer_mode !== 'escpos') { win.webContents.print({ silent: false, printBackground: false, margins: { marginType: 'none' } }); return { mode: 'system' }; }
  if (typeof html !== 'string' || html.length > 200000) throw new Error('invalid_receipt');
  const dots = escpos.dotsFor(s.paper_width), H = 3000;
  const w = new BrowserWindow({ show: false, width: dots, height: H, useContentSize: true, webPreferences: { offscreen: true, javascript: false, sandbox: true, contextIsolation: true } });
  try {
    const page = `<!doctype html><html dir="${dir === 'ltr' ? 'ltr' : 'rtl'}"><meta charset="utf-8"><style>*{box-sizing:border-box}body{margin:0;padding:10px;width:${dots}px;background:#fff;color:#000;font:22px/1.4 "Segoe UI",Tahoma,Arial,sans-serif}.tl{display:flex;justify-content:space-between;gap:8px}hr{border:0;border-top:2px dashed #000;margin:8px 0}</style><body>${html}</body></html>`;
    await w.loadURL('data:text/html;charset=utf-8;base64,' + Buffer.from(page).toString('base64'));
    await new Promise((r) => setTimeout(r, 250));
    let img = await w.webContents.capturePage();
    if (img.getSize().width !== dots) img = img.resize({ width: dots });
    const { width, height } = img.getSize();
    await printer.send(s, escpos.build(img.toBitmap(), width, height, { cut: s.printer_cut !== '0', drawer: s.printer_drawer === '1' }));
    return { mode: 'escpos' };
  } finally { w.destroy(); }
}

// ===== شاشة الإقلاع: نافذة صغيرة تظهر فوراً وتعرض خطوات التشغيل الحقيقية =====
let splash = null;
const ICON = path.join(__dirname, 'assets', 'icon.ico');
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
function showSplash() {
  splash = new BrowserWindow({ width: 600, height: 360, frame: false, transparent: true, resizable: false, maximizable: false, fullscreenable: false, center: true, show: false, icon: ICON, title: 'Store Accounting Pro',
    webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true } });
  splash.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  splash.webContents.on('will-navigate', (e) => e.preventDefault());
  const loaded = splash.loadFile(path.join(__dirname, 'renderer', 'splash.html'), { query: { v: app.getVersion() } }).catch(() => {});
  splash.once('ready-to-show', () => splash && !splash.isDestroyed() && splash.show());
  return loaded;
}
function splashStep(i) {
  if (splash && !splash.isDestroyed()) splash.webContents.executeJavaScript('window.step&&step(' + Number(i) + ')').catch(() => {});
}
function closeSplash() { if (splash && !splash.isDestroyed()) splash.destroy(); splash = null; }

app.whenReady().then(async () => {
  if (!gotLock) return;
  const started = Date.now();
  await showSplash();
  await wait(250);
  try { db.open(app.getPath('userData')); }
  catch (e) {
    closeSplash();
    dialog.showErrorBox('تعذّر فتح قاعدة البيانات', 'لم يتمكن البرنامج من فتح ملف البيانات.\n\n' + e.message + '\n\nمكان الملف:\n' + path.join(app.getPath('userData'), 'store.db') + '\n\nأغلق أي نسخة أخرى من البرنامج ثم أعد المحاولة، أو استعد نسخة احتياطية.');
    app.exit(1); return;
  }
  splashStep(1); await wait(300);
  const BK = path.join(app.getPath('userData'), 'backups');
  const safeBackup = (force) => { try { return backup.auto(BK, force); } catch (e) { console.error('backup failed', e.message); return null; } };
  safeBackup(false); setInterval(() => safeBackup(false), 3600 * 1000); // عند التشغيل ثم كل ساعة: تُنفَّذ فقط إن مرّ أكثر من 24 ساعة
  splashStep(2);
  win = new BrowserWindow({ width: 1366, height: 820, minWidth: 900, autoHideMenuBar: true, show: false, icon: ICON, backgroundColor: '#14171c', title: 'برنامج المحاسبة · Store Accounting Pro',
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true } });
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.webContents.on('will-navigate', (event) => event.preventDefault());
  win.webContents.on('before-input-event', (event, input) => {
    if (app.isPackaged && (input.key === 'F12' || (input.control && input.shift && ['I','J','C'].includes(input.key)))) event.preventDefault();
  });
  if (app.isPackaged) win.webContents.closeDevTools();
  win.once('ready-to-show', async () => {
    splashStep(3);
    const left = 1800 - (Date.now() - started); // حد أدنى قصير حتى لا تومض الشاشة
    await wait(Math.max(left, 450));
    win.maximize(); win.show(); win.focus(); closeSplash();
  });
  win.on('closed', () => { win = null; });
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));

  handle('auth:needsSetup', null, () => db.needsSetup());
  handle('auth:setup', null, (a) => db.createAdmin(a));
  handle('auth:login', null, (a) => { const u = db.login(a.username, a.password); if (!u) throw new Error('bad_credentials'); return (user = u); });
  handle('auth:logout', null, () => { user = null; });

  handle('settings:get', ANY, () => db.getSettings());
  handle('settings:set', ADMIN, (a) => db.setSettings(a));
  handle('branch:list', ANY, () => db.listBranches());
  handle('branch:add', ADMIN, (a) => db.addBranch(a));
  handle('user:add', ADMIN, (a) => db.addUser(a));
  handle('product:list', ANY, () => db.listProducts());
  handle('product:save', ADMIN, (a) => db.saveProduct(a));
  handle('stock:get', ANY, (a) => db.getStock(user.role === 'sales' ? user.branch_id : a.branchId));
  handle('stock:alerts', ANY, (a) => db.lowStock(user.role === 'sales' ? user.branch_id : a?.branchId));
  handle('stock:min', ADMIN, (a) => db.setMinStock(user, a));
  handle('stock:inventoryAdjust', ADMIN, (a) => db.inventoryAdjust(user, a));
  handle('invoice:create', ANY, (a) => db.createInvoice(user, a));
  handle('transfer:create', ADMIN, (a) => db.createTransfer(user, a));
  handle('transfer:send', ADMIN, (a) => db.sendTransfer(user, a.id));
  handle('transfer:receive', ANY, (a) => db.receiveTransfer(user, a.id));
  handle('transfer:cancel', ADMIN, (a) => db.cancelTransfer(a.id));
  handle('transfer:list', ANY, () => db.listTransfers(user));
  handle('report:sales', ANY, (a) => db.salesReport(user, a));
  handle('account:list', ADMIN, () => db.accountList());
  handle('account:journal', ADMIN, (a) => db.journalList(a || {}));
  handle('account:summary', ADMIN, (a) => db.accountSummary(a || {}));
  handle('party:balances', ADMIN, (a) => db.partyBalances(a.kind));
  handle('party:pay', ADMIN, (a) => db.payParty(user, a));
  handle('party:payments', ADMIN, (a) => db.paymentList(a || {}));
  handle('report:export', ADMIN, async (a) => { const r=await dialog.showSaveDialog(win,{defaultPath:a.filename||'report.csv',filters:[{name:a.kind==='pdf'?'PDF':'Excel CSV',extensions:[a.kind==='pdf'?'pdf':'csv']}]}); if(r.canceled||!r.filePath)return {canceled:true}; if(a.kind==='pdf'){const w=new BrowserWindow({show:false});await w.loadURL('data:text/html;charset=utf-8,'+encodeURIComponent(a.html||''));const b=await w.webContents.printToPDF({printBackground:true});fs.writeFileSync(r.filePath,b);w.destroy()}else fs.writeFileSync(r.filePath,'\ufeff'+String(a.content||''),'utf8');return {canceled:false,file:r.filePath}; });
  handle('user:list', ADMIN, () => db.listUsers());
  handle('user:setPermissions', ADMIN, (a) => db.setPermissions(user, a));
  handle('sales:list', ANY, (a) => db.listSales(user, a));        // الموظف: يحتاج صلاحية العرض، ويرى مبيعاته اليوم فقط
  handle('sales:delete', ANY, (a) => db.deleteSale(user, a.id));  // الصلاحية تُفحص داخل db.js
  handle('sales:update', ANY, (a) => db.updateSale(user, a));
  handle('sales:openSummary', ADMIN, (a) => db.openSummary(user, a));
  handle('sales:endOfDay', ADMIN, (a) => { const r = db.endOfDay(user, a); safeBackup(true); return r; }); // نسخة احتياطية بعد كل إنهاء يوم
  handle('sales:eodHistory', ADMIN, () => db.listEndOfDay());
  handle('sales:audit', ADMIN, () => db.listAudit());
  handle('product:delete', ADMIN, (a) => db.deleteProduct(a.id));
  handle('stock:adjust', ADMIN, (a) => db.adjustStock(user, a));
  handle('branch:delete', ADMIN, (a) => db.deleteBranch(a.id));
  handle('user:delete', ADMIN, (a) => db.deleteUser(a.id));
  handle('sales:all', ADMIN, () => db.allInvoices());
  handle('expense:add', ADMIN, (a) => db.addExpense(user, a));
  handle('expense:list', ADMIN, () => db.listExpenses());
  handle('purchase:create', ADMIN, (a) => db.createPurchase(user, a));
  handle('purchase:list', ADMIN, (a) => db.listPurchases(a || {}));
  handle('party:list', ANY, (a) => db.listParties(a));
  handle('party:add', ANY, (a) => db.addParty(a));
  handle('party:update', ANY, (a) => db.updateParty(a));
  handle('party:delete', ADMIN, (a) => db.deleteParty(a));
  handle('backup:list', ADMIN, () => ({ dir: BK, items: backup.list(BK) }));
  handle('backup:now', ADMIN, () => backup.make(BK));
  handle('backup:restore', ADMIN, (a) => backup.restore(BK, { name: a.name }, () => { app.relaunch(); app.exit(0); }));
  handle('backup:restoreFile', ADMIN, async () => {
    const r = await dialog.showOpenDialog(win, { properties: ['openFile'], filters: [{ name: 'Backup', extensions: ['db'] }] });
    if (r.canceled || !r.filePaths[0]) return { canceled: true };
    backup.restore(BK, { file: r.filePaths[0] }, () => { app.relaunch(); app.exit(0); }); return { canceled: false };
  });
  handle('backup:pickFolder', ADMIN, async () => {
    const r = await dialog.showOpenDialog(win, { properties: ['openDirectory', 'createDirectory'] });
    return r.canceled ? null : r.filePaths[0];
  });
  handle('print:receipt', ANY, (a) => printHtml(a));
  handle('print:test', ADMIN, () => printHtml({ html: '<div style="text-align:center"><b>' + esc(db.getSettings().store_name) + '</b><br>إيصال تجريبي · Test receipt<br>1234567890 ABC أبجد هوز</div>', dir: 'rtl' }));
  handle('print:list', ADMIN, async () => (await win.webContents.getPrintersAsync()).map(p => ({ name: p.name, isDefault: p.isDefault })));
});
app.on('before-quit', () => { try { db.closeDb(); } catch (_) {} });
app.on('window-all-closed', () => { if (!splash) app.quit(); });
