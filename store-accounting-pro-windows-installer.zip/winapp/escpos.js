// ESC/POS: تحويل صورة الإيصال إلى أوامر طابعة حرارية.
// نطبع الإيصال كصورة نقطية فتظهر العربية بشكل صحيح على أي طابعة دون الاعتماد على جداول الحروف فيها.

// عرض الطباعة بالنقاط (203 dpi): 80mm = 576، 58mm = 384
const dotsFor = (paperMm) => (String(paperMm) === '58' ? 384 : 576);

// bgra: Buffer بصيغة BGRA (من NativeImage.toBitmap). يُقصّ الفراغ الأبيض أسفل الإيصال ويُترك هامش بسيط.
function trimBottom(bgra, w, h, pad = 24, threshold = 160) {
  let last = -1;
  for (let y = h - 1; y >= 0 && last < 0; y--)
    for (let x = 0; x < w; x++) {
      const i = (y * w + x) * 4;
      if (bgra[i + 3] >= 128 && 0.299 * bgra[i + 2] + 0.587 * bgra[i + 1] + 0.114 * bgra[i] < threshold) { last = y; break; }
    }
  return Math.min(h, last + 1 + pad);
}

// صورة 1-bit: كل بايت = 8 نقاط أفقية، البت الأعلى = أقصى اليسار، 1 = أسود
function toRaster(bgra, w, h, threshold = 160) {
  const wb = Math.ceil(w / 8), out = Buffer.alloc(wb * h);
  for (let y = 0; y < h; y++)
    for (let x = 0; x < w; x++) {
      const i = (y * w + x) * 4;
      const lum = bgra[i + 3] < 128 ? 255 : 0.299 * bgra[i + 2] + 0.587 * bgra[i + 1] + 0.114 * bgra[i];
      if (lum < threshold) out[y * wb + (x >> 3)] |= 0x80 >> (x & 7);
    }
  return { data: out, widthBytes: wb };
}

const INIT = Buffer.from([0x1b, 0x40]);
const feed = (n) => Buffer.from([0x1b, 0x64, n]);
const CUT = Buffer.from([0x1d, 0x56, 0x42, 0x03]);        // GS V 66 3: تغذية ثم قص جزئي
const DRAWER = Buffer.from([0x1b, 0x70, 0x00, 0x19, 0xfa]); // ESC p: فتح درج النقود

// GS v 0 على شرائح من 128 سطراً (بعض الطابعات تتعثر مع الصور الطويلة دفعة واحدة)
function rasterCommands(bgra, w, h) {
  const { data, widthBytes } = toRaster(bgra, w, h), parts = [], BAND = 128;
  for (let y = 0; y < h; y += BAND) {
    const n = Math.min(BAND, h - y);
    parts.push(Buffer.from([0x1d, 0x76, 0x30, 0x00, widthBytes & 255, widthBytes >> 8, n & 255, n >> 8]), data.subarray(y * widthBytes, (y + n) * widthBytes));
  }
  return Buffer.concat(parts);
}

// opts: { cut = true, drawer = false, feedLines = 3 }
function build(bgra, w, h, opts = {}) {
  const { cut = true, drawer = false, feedLines = 3 } = opts, hh = trimBottom(bgra, w, h);
  return Buffer.concat([INIT, rasterCommands(bgra, w, hh), feed(feedLines), cut ? CUT : Buffer.alloc(0), drawer ? DRAWER : Buffer.alloc(0)]);
}

module.exports = { dotsFor, trimBottom, toRaster, rasterCommands, build, CUT, DRAWER, INIT };
