-- مخطط قاعدة البيانات (SQLite) - برنامج محاسبة ونقطة بيع متعدد الفروع
-- كل المبالغ تُخزَّن كأعداد صحيحة بأصغر وحدة (فلس = 1/100 من الدرهم) لتجنب أخطاء الكسور.
PRAGMA foreign_keys = ON;

CREATE TABLE settings (
  key   TEXT PRIMARY KEY,           -- store_name, trn, address, phone, currency_symbol, currency_code, vat_percent, receipt_footer
  value TEXT NOT NULL
);

CREATE TABLE branches (
  id      INTEGER PRIMARY KEY,
  name    TEXT NOT NULL UNIQUE,
  code    TEXT NOT NULL UNIQUE,     -- يُستخدم في ترقيم الفواتير، مثل B1
  address TEXT,
  phone   TEXT,
  active  INTEGER NOT NULL DEFAULT 1,
  last_invoice_no INTEGER NOT NULL DEFAULT 1000      -- عدّاد الفواتير: لا يُعاد استخدام رقم فاتورة محذوفة
);

CREATE TABLE users (
  id            INTEGER PRIMARY KEY,
  username      TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,                       -- تجزئة مشفّرة، لا تُخزَّن كلمة المرور نفسها
  full_name     TEXT NOT NULL,
  role          TEXT NOT NULL CHECK (role IN ('admin','sales')),
  branch_id     INTEGER REFERENCES branches(id),     -- موظف المبيعات مرتبط بفرع؛ المدير NULL (كل الفروع)
  lang          TEXT NOT NULL DEFAULT 'ar' CHECK (lang IN ('ar','en')),
  active        INTEGER NOT NULL DEFAULT 1,
  perm_view     INTEGER NOT NULL DEFAULT 0,          -- صلاحية عرض المبيعات اليومية (يمنحها المدير)
  perm_edit     INTEGER NOT NULL DEFAULT 0,          -- صلاحية تعديل المبيعات المفتوحة
  perm_delete   INTEGER NOT NULL DEFAULT 0,          -- صلاحية حذف المبيعات المفتوحة
  perm_discount INTEGER NOT NULL DEFAULT 0,          -- صلاحية منح خصم على الفاتورة (بسقف نسبة في الإعدادات)
  CHECK (role = 'admin' OR branch_id IS NOT NULL)
);

CREATE TABLE product_groups (
  id      INTEGER PRIMARY KEY,
  name_ar TEXT NOT NULL,
  name_en TEXT
);

CREATE TABLE products (
  id            INTEGER PRIMARY KEY,
  name_ar       TEXT NOT NULL,
  name_en       TEXT,
  barcode       TEXT UNIQUE,
  group_id      INTEGER REFERENCES product_groups(id),
  price         INTEGER NOT NULL CHECK (price >= 0),  -- السعر شامل الضريبة
  cost          INTEGER NOT NULL DEFAULT 0,
  track_stock   INTEGER NOT NULL DEFAULT 1,           -- 0 للخدمات
  active        INTEGER NOT NULL DEFAULT 1
);

-- المخزون لكل فرع
CREATE TABLE stock (
  branch_id  INTEGER NOT NULL REFERENCES branches(id),
  product_id INTEGER NOT NULL REFERENCES products(id),
  qty        INTEGER NOT NULL DEFAULT 0,
  min_qty    INTEGER NOT NULL DEFAULT 0,              -- حد التنبيه
  PRIMARY KEY (branch_id, product_id)
);

-- سجل كل حركة مخزون (بيع، شراء، نقل، تسوية)
CREATE TABLE stock_movements (
  id         INTEGER PRIMARY KEY,
  branch_id  INTEGER NOT NULL REFERENCES branches(id),
  product_id INTEGER NOT NULL REFERENCES products(id),
  qty_change INTEGER NOT NULL,
  reason     TEXT NOT NULL CHECK (reason IN ('sale','purchase','transfer_out','transfer_in','adjustment','return')),
  ref_id     INTEGER,                                 -- رقم الفاتورة أو أمر النقل
  user_id    INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- نقل المخزون بين الفروع: مسودة ← مُرسَل (يُخصم من المصدر) ← مستلَم (يُضاف للوجهة)
CREATE TABLE stock_transfers (
  id             INTEGER PRIMARY KEY,
  from_branch_id INTEGER NOT NULL REFERENCES branches(id),
  to_branch_id   INTEGER NOT NULL REFERENCES branches(id),
  status         TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','sent','received','cancelled')),
  note           TEXT,
  created_by     INTEGER NOT NULL REFERENCES users(id),
  created_at     TEXT NOT NULL DEFAULT (datetime('now')),
  sent_at        TEXT,
  received_at    TEXT,
  CHECK (from_branch_id <> to_branch_id)
);

CREATE TABLE stock_transfer_items (
  transfer_id INTEGER NOT NULL REFERENCES stock_transfers(id) ON DELETE CASCADE,
  product_id  INTEGER NOT NULL REFERENCES products(id),
  qty         INTEGER NOT NULL CHECK (qty > 0),
  PRIMARY KEY (transfer_id, product_id)
);

CREATE TABLE customers (
  id      INTEGER PRIMARY KEY,
  name    TEXT NOT NULL,
  phone   TEXT,
  trn     TEXT,
  balance INTEGER NOT NULL DEFAULT 0                  -- رصيد الدين
);

CREATE TABLE suppliers (
  id      INTEGER PRIMARY KEY,
  name    TEXT NOT NULL,
  phone   TEXT,
  trn     TEXT,
  balance INTEGER NOT NULL DEFAULT 0
);

-- إنهاء اليوم: ترحيل يدوي لمبيعات الموظفين المفتوحة (branch_id NULL = كل الفروع)
CREATE TABLE end_of_day (
  id         INTEGER PRIMARY KEY,
  branch_id  INTEGER REFERENCES branches(id),
  user_id    INTEGER NOT NULL REFERENCES users(id),
  invoices   INTEGER NOT NULL,
  total      INTEGER NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

-- سجل التعديلات: من عدّل أو حذف أي فاتورة ومتى (لقطة قبل التغيير)
CREATE TABLE audit_log (
  id         INTEGER PRIMARY KEY,
  user_id    INTEGER NOT NULL REFERENCES users(id),
  action     TEXT NOT NULL,                          -- delete_invoice | edit_invoice | end_of_day | set_permissions
  branch_id  INTEGER,
  invoice_no INTEGER,
  detail     TEXT,                                   -- JSON
  created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE invoices (
  id             INTEGER PRIMARY KEY,
  branch_id      INTEGER NOT NULL REFERENCES branches(id),
  number         INTEGER NOT NULL,                    -- تسلسل مستقل لكل فرع
  user_id        INTEGER NOT NULL REFERENCES users(id),
  customer_id    INTEGER REFERENCES customers(id),    -- NULL = عميل نقدي
  payment_method TEXT NOT NULL CHECK (payment_method IN ('cash','card')),
  vat_percent    REAL NOT NULL,
  subtotal       INTEGER NOT NULL,                    -- قبل الضريبة
  vat_amount     INTEGER NOT NULL,
  total          INTEGER NOT NULL,                    -- شامل الضريبة وبعد الخصم
  discount       INTEGER NOT NULL DEFAULT 0,          -- مبلغ الخصم (شامل الضريبة)، الإجمالي قبل الخصم = total + discount
  created_at     TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  status         TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open','posted')),  -- open = قابلة للتعديل/الحذف، posted = مرحّلة ومقفلة
  posted_at      TEXT,
  eod_id         INTEGER REFERENCES end_of_day(id),
  UNIQUE (branch_id, number)
);

CREATE TABLE invoice_items (
  id         INTEGER PRIMARY KEY,
  invoice_id INTEGER NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
  product_id INTEGER NOT NULL REFERENCES products(id),
  name       TEXT NOT NULL,                           -- نسخة من الاسم وقت البيع
  qty        INTEGER NOT NULL CHECK (qty > 0),
  unit_price INTEGER NOT NULL,                        -- شامل الضريبة
  line_total INTEGER NOT NULL
);

CREATE TABLE expenses (
  id         INTEGER PRIMARY KEY,
  branch_id  INTEGER NOT NULL REFERENCES branches(id),
  category   TEXT NOT NULL,
  amount     INTEGER NOT NULL CHECK (amount > 0),
  note       TEXT,
  user_id    INTEGER REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- فواتير الشراء من الموردين: تزيد المخزون، والآجل يزيد رصيد المورد
CREATE TABLE purchases (
  id          INTEGER PRIMARY KEY,
  branch_id   INTEGER NOT NULL REFERENCES branches(id),
  supplier_id INTEGER REFERENCES suppliers(id),
  ref_no      TEXT,                                   -- رقم فاتورة المورد
  payment     TEXT NOT NULL CHECK (payment IN ('cash','credit')),
  total       INTEGER NOT NULL,                       -- إجمالي التكلفة
  note        TEXT,
  user_id     INTEGER NOT NULL REFERENCES users(id),
  created_at  TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  CHECK (payment = 'cash' OR supplier_id IS NOT NULL)
);
CREATE TABLE purchase_items (
  id          INTEGER PRIMARY KEY,
  purchase_id INTEGER NOT NULL REFERENCES purchases(id) ON DELETE CASCADE,
  product_id  INTEGER NOT NULL REFERENCES products(id),
  qty         INTEGER NOT NULL CHECK (qty > 0),
  unit_cost   INTEGER NOT NULL CHECK (unit_cost >= 0),
  line_total  INTEGER NOT NULL
);
CREATE INDEX idx_purchases_branch_date ON purchases(branch_id, created_at);

CREATE INDEX idx_invoices_branch_date ON invoices(branch_id, created_at);
CREATE INDEX idx_invoices_status       ON invoices(status, branch_id);
CREATE INDEX idx_items_invoice        ON invoice_items(invoice_id);
CREATE INDEX idx_moves_branch_prod    ON stock_movements(branch_id, product_id);
CREATE INDEX idx_expenses_branch_date ON expenses(branch_id, created_at);

-- تقارير: المبيعات الشهرية لكل فرع. للتقرير المجمّع لكل الفروع: SUM(...) GROUP BY month
CREATE VIEW v_sales_by_branch_month AS
SELECT branch_id,
       strftime('%Y-%m', created_at) AS month,
       COUNT(*)        AS invoices,
       SUM(subtotal)   AS subtotal,
       SUM(vat_amount) AS vat,
       SUM(total)      AS total
FROM invoices
WHERE status = 'posted'
GROUP BY branch_id, month;

CREATE VIEW v_sales_all_branches_month AS
SELECT month, SUM(invoices) AS invoices, SUM(subtotal) AS subtotal, SUM(vat) AS vat, SUM(total) AS total
FROM v_sales_by_branch_month
GROUP BY month;

-- بيانات أولية
INSERT INTO settings(key,value) VALUES
 ('store_name','اسم المتجر'),('trn',''),('address',''),('phone',''),
 ('currency_symbol','د.إ'),('currency_code','AED'),('vat_percent','5'),
 ('receipt_footer','شكراً لزيارتكم'),('schema_version','1'),
 -- الطابعة الافتراضية: ESC/POS حرارية 80mm عامة (Epson TM-T20 / Xprinter). تُعدَّل من شاشة الإعدادات.
 ('employee_max_discount','20'),('backup_auto','1'),('backup_keep','30'),('backup_dir',''),
 ('printer_mode','escpos'),('printer_model','generic-escpos-80'),('printer_type','usb'),('printer_name',''),('printer_ip',''),('printer_port','9100'),('paper_width','80'),('printer_cut','1'),('printer_drawer','0');
INSERT INTO branches(name,code) VALUES ('الفرع الرئيسي','B1');
-- حساب المدير الأول يُنشأ عند أول تشغيل بكلمة مرور يختارها المستخدم (لا كلمة مرور افتراضية في قاعدة البيانات).
